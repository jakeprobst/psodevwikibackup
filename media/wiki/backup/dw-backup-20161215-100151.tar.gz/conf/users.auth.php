# users.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Userfile
#
# Format:
#
# login:passwordhash:Real Name:email:groups,comma,seperated


jake:$1$UsVTINYw$2/MtaynCa24kFK7IxQwk41:jake:jake@sharnoth.com:admin,user
soly:$1$jClgDzrF$nuAtll5BRT7krlabiUJUl.:Soleil Rojas:soleilrojas@gmail.com:user
eidolon:$1$mWwVW2rr$T13/Ju.Ch/8DjNF4OYMBr1:eidolon:furyhunter600@gmail.com:user
wilhuf:$1$JWjydjgj$2hFGJHLLSXpet/llkpOhx.:Daan:daan@daanvandenbosch.com:admin,user
