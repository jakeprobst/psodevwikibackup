<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Jaroslav Lichtblau <jlichtblau@seznam.cz>
 */
$lang['connectfail']           = 'Selhalo připojení k databázi.';
$lang['userexists']            = 'Omlouváme se, ale uživatel s tímto jménem již existuje.';
$lang['writefail']             = 'Nelze změnit údaje uživatele. Informujte prosím správce wiki';
