<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Mete Cuma <mcumax@gmail.com>
 */
$lang['connectfail']           = 'Veritabanına bağlantı kurulamadı.';
