<?php
/**
 * Welsh language file for authmysql plugin
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */

$lang['connectfail']    = 'Method y cysylltiad i\'r databas.';
$lang['userexists']     = 'Sori, mae defnyddiwr gyda\'r enw mewngofnodi hwn eisoes yn bodoli.';
$lang['writefail']      = 'Methu â newid data defnyddiwr. Rhowch wybod i Weinyddwr y Wici';

//Setup VIM: ex: et ts=4 :
