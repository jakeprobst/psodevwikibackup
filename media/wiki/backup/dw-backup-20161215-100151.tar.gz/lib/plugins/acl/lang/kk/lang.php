<?php
/**
 * kazakh language file
 *
 * @author Nurgozha Kaliaskarov astana08@gmail.com
 */
$lang['acl_group']             = 'Группа:';
$lang['acl_user']              = 'Пайдаланушы:';
$lang['page']                  = 'Бет';
$lang['acl_perm1']             = 'Оқу';
