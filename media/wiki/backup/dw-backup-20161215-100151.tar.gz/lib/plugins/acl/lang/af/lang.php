<?php
/**
 * Afrikaans language file
 *
 */
$lang['page']                  = 'Bladsy';
$lang['acl_perm0']             = 'Niks';
$lang['acl_perm1']             = 'Lees';
$lang['acl_perm2']             = 'Verander';
$lang['acl_perm4']             = 'Maak';
