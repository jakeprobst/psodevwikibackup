<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Jacob Palm <mail@jacobpalm.dk>
 */
$lang['connectfail']           = 'Kunne ikke forbinde til databasen.';
$lang['userexists']            = 'Beklager, en bruger med dette login findes allerede.';
$lang['usernotexists']         = 'Beklager, brugeren eksisterer ikke.';
