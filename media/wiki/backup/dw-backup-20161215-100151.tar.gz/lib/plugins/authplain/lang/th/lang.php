<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 */
$lang['userexists']            = 'ชื่อบัญชีที่ใส่นั้นมีผู้อื่นได้ใช้แล้ว กรุณาเลือกชื่อผู้ใช้อื่น';
