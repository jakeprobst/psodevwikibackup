<?php
/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */
$lang['userexists']     = 'Die gebruikersnaam wat jy gebruik het, is alreeds gebruik. Kies asseblief \'n ander gebruikersnaam.';
