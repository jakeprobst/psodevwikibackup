<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Paulo Carmino <contato@paulocarmino.com>
 */
$lang['userexists']            = 'Este utilizador já está inscrito. Por favor escolha outro nome de utilizador.';
$lang['usernotexists']         = 'Desculpe, esse login não existe.';
