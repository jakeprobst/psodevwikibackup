<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Jussi Takala <jussi.takala@live.fi>
 */
$lang['authpwdexpire']         = 'Salasanasi vanhenee %d pv:n päästä, vaihda salasanasi pikaisesti.';
