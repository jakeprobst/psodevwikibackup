<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Daniel López Prat <daniel@6temes.cat>
 */
$lang['authpwdexpire']         = 'La vostra contrasenya caducarà en %d dies, l\'hauríeu de canviar aviat.';
