<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Zigor Astarbe <astarbe@gmail.com>
 */
$lang['authpwdexpire']         = 'Zure pasahitza %d egun barru iraungiko da, laster aldatu beharko zenuke.';
