<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author tomer <tomercarolldergicz@gmail.com>
 * @author Menashe Tomer <menashesite@gmail.com>
 */
$lang['authpwdexpire']         = 'הסיסמה שלך תפוג ב %d ימים, אתה צריך לשנות את זה בקרוב.';
$lang['passchangefail']        = 'שגיאה בשינוי סיסמה. האם הסיסמה תואמת למדיניות המערכת?';
