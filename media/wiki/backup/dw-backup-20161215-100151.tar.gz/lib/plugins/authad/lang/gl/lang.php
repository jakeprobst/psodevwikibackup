<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Rodrigo Rega <rodrigorega@gmail.com>
 */
$lang['authpwdexpire']         = 'A túa contrasinal expirará en %d días, deberías cambiala pronto.';
