<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Vasileios Karavasilis vasileioskaravasilis@gmail.com
 */
$lang['authpwdexpire']         = 'Ο κωδικός πρόσβασης θα λήξει σε %d ημέρες. Προτείνουμε να τον αλλάξετε σύντομα.';
