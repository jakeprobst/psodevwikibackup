<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Janar Leas <janar.leas@eesti.ee>
 */
$lang['authpwdexpire']         = 'Sinu salasõna aegub %d päeva pärast, võiksid seda peatselt muuta.';
