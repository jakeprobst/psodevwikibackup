<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author matej <mateju@svn.gnome.org>
 * @author Jernej Vidmar <jernej.vidmar@vidmarboehm.com>
 */
$lang['starttls']              = 'Ali naj se uporabijo povezave TLS?';
$lang['bindpw']                = 'Geslo uporabnika zgoraj';
