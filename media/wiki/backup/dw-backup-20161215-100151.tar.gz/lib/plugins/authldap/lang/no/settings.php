<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Christopher Schive <chschive@frisurf.no>
 * @author Patrick <spill.p@hotmail.com>
 */
$lang['port']                  = 'LDAP serverport dersom ingen full URL var gitt over.';
$lang['starttls']              = 'Bruke TLS-forbindelser?';
$lang['bindpw']                = 'Passord til brukeren over';
