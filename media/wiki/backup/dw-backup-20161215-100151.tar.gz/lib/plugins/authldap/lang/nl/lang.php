<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hugo Smet <hugo.smet@scarlet.be>
 */
$lang['connectfail']           = 'LDAP kan niet connecteren: %s';
$lang['domainfail']            = 'LDAP kan je gebruikers dn niet vinden';
