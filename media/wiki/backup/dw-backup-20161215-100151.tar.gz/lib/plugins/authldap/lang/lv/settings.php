<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Aivars Miška <allefm@gmail.com>
 */
$lang['starttls']              = 'Lietot TLS  savienojumus?';
$lang['bindpw']                = 'Lietotāja parole';
