<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Otto Vainio <otto@valjakko.net>
 */
$lang['starttls']              = 'Käytä TLS yhteyttä';
$lang['bindpw']                = 'Ylläolevan käyttäjän salasana';
$lang['userscope']             = 'Etsi vain käyttäjiä';
$lang['groupscope']            = 'Etsi vain ryhmiä';
