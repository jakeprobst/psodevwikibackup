<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author matt carroll <matt.carroll@gmail.com>
 * @author Menashe Tomer <menashesite@gmail.com>
 */
$lang['starttls']              = 'השתמש בחיבורי TLS';
$lang['modPass']               = 'האם dokuwiki יכול ליצור סיסמאות LDAP?';
$lang['debug']                 = 'הצג מידע נוסף על שגיאות';
$lang['referrals_o_-1']        = 'ברירת מחדל';
