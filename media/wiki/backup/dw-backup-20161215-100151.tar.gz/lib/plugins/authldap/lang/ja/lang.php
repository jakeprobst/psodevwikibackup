<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Hideaki SAWADA <chuno@live.jp>
 */
$lang['connectfail']           = 'LDAP に接続できません： %s';
$lang['domainfail']            = 'LDAP で user dn を発見できません。';
