<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Myeongjin <aranet100@gmail.com>
 */
$lang['connectfail']           = 'LDAP가 연결할 수 없습니다: %s';
$lang['domainfail']            = 'LDAP가 사용자 DN을 찾을 수 없습니다';
