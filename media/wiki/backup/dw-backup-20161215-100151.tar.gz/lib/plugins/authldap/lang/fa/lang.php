<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Masoud Sadrnezhaad <masoud@sadrnezhaad.ir>
 */
$lang['connectfail']           = 'LDAP نمیتواند وصل شود: %s';
$lang['domainfail']            = 'LDAP نمیتواند کاربر شما را پیدا کند';
